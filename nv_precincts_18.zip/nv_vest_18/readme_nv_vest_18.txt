2018 Nevada precinct and election shapefile.

## RDH Date retrieval
07/12/2020

## Sources
Election results from Nevada Secretary of State (https://www.nvsos.gov/sos/elections/election-information/precinct-level-results)

Precinct shapefiles primarily from the U.S. Census Bureau's 2020 Redistricting Data Program Phase 2 release. The following counties used shapefiles sourced from the respective county governments instead: Clark, Douglas, Elko, Humboldt, Lincoln, Lyon, Washoe.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G16PREDCli
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
A## - Ballot amendment, where ## is an identifier
AGR - Commissioner of Agriculture
ATG - Attorney General
AUD - Auditor
CFO - Chief Financial Officer
CHA - Council Chairman
COC - Corporation Commissioner
COM - Comptroller
CON - State Controller
COU - City Council Member
CSC - Clerk of the Supreme Court
DEL - Delegate to the U.S. House
GOV - Governor
H## - U.S. House, where ## is the district number. AL: at large.
HOD - House of Delegates, accompanied by a HOD_DIST column indicating district number
HOR - U.S. House, accompanied by a HOR_DIST column indicating district number
INS - Insurance Commissioner
LAB - Labor Commissioner
LND - Commissioner of Public/State Lands
LTG - Lieutenant Governor
MAY - Mayor
MNI - State Mine Inspector
PSC - Public Service Commissioner
PUC - Public Utilities Commissioner
RGT - State University Regent
SAC - State Appeals Court
SBE - State Board of Education
SOC - Secretary of Commonwealth
SOS - Secretary of State
SPI - Superintendent of Public Instruction
SPL - Commissioner of School and Public Lands
SSC - State Supreme Court
TAX - Tax Commissioner
TRE - Treasurer
UBR - University Board of Regents/Trustees/Governors
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.

## Fields
G18USSDROS - Jacky Rosen (Democratic Party)
G18USSRHEL - Dean Heller (Republican Party)
G18USSLHAG - Tim Hagan (Libertarian Party)
G18USSIBAK - Kamau A. Bakari (Independent American Party)
G18USSNMIC - Barry Michaels (No Political Party)
G18USSONON - None of These Candidates

G18GOVDSIS - Steve Sisolak (Democratic Party)
G18GOVRLAX - Adam Paul Laxalt (Republican Party)
G18GOVLLOR - Jared Lord (Libertarian Party)
G18GOVIBES - Russell Best (Independent American Party)
G18GOVNBUN - Ryan Bundy (No Political Party)
G18GOVONON - None of These Candidates

G18LTGDMAR - Kate Marshall (Democratic Party)
G18LTGRROB - Michael Roberson (Republican Party)
G18LTGIHAN - Janine Hansen (Independent American Party)
G18LTGNUEH - Ed Uehling (No Political Party)
G18LTGONON - None of These Candidates

G18ATGDFOR - Aaron Ford (Democratic Party)
G18ATGRDUN - Wes Duncan (Republican Party)
G18ATGIHAN - Joel F. Hansen (Independent American Party)
G18ATGONON - None of These Candidates

G18SOSDARA - Nelson Araujo (Democratic Party)
G18SOSRCEG - Barbara K. Cegavske (Republican Party)
G18SOSONON - None of These Candidates

G18TREDCON - Zach Conine (Democratic Party)
G18TRERBEE - Bob Beers (Republican Party)
G18TREIHOG - Bill Hoge (Independent American Party)
G18TREONON - None of These Candidates

G18CONDBYR - Catherine Byrne (Democratic Party)
G18CONRKNE - Ron Knecht (Republican Party)
G18CONONON - None of These Candidates

## Processing Steps
County borders in all county-sourced shapefiles were aligned to the U.S Census Bureau's boundaries. Minor adjustments were made in the Precinct 1/3 boundary of Eureka County and in the Precinct 6/5 boundary of Pershing County to match county GIS maps. Substantial revisions were made in the Fallon area of Churchill County and in the Tonopah area of Nye County to match county PDF maps.

Countywide-reported federal ballots for the U.S. Senate race in Clark, Douglas, Elko, Humboldt, Lyon, Nye, and Washoe were distributed by candidate based on the precinct-level reported vote.